package com.example.pogorelova_v_18

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
    }
    fun onClick(v: View?) {
        val intent = Intent(this@login, personal_area::class.java)
        startActivity(intent)
    }
}